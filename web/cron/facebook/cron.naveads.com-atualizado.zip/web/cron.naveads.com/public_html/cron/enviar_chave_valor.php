<?php 
header("Access-Control-Allow-Origin: *");

set_time_limit(0);

include('../config.php'); 
include(ABSPATH .'/funcoes.php'); 

$pasta    = ABSPATH . 'cron/arquivos/chave_valor/';
$arquivos = glob($pasta . '*.txt');

$linkCopiado = 'https://gestor.naveads.com/ajax.php?salvaGestaoUtmsCopias';
$linkAtual   = 'https://adx.naveads.com/adx/nave_chave_valor.php';

$total = count($arquivos);
if ($total > 0) {
    echo 'parar';
} else {
    $dataAtual = date('Y-m-d');
    if (isset($_GET['data']))
        $dataAtual = $_GET['data'];
        
    $tipo = '';
    if (isset($_GET['tipo']))
        $tipo = $_GET['tipo'];

    $contas = mysqli_query($con, "SELECT *
        FROM adx_contas ");

    if ($contas) {
        while ($contaValor = mysqli_fetch_array($contas)) {
            $contaSites = (array) json_decode($contaValor['contaSites'], true);
            $contaSites = array_filter($contaSites);
            
            $network_code    = $contaValor['contaCodigo'];
            $aplication_code = $contaValor['contaNome'];
            
            if (count($contaSites) > 0) {
                
                $linkTipo    = '';
                $linkCampo   = '';

                if ($tipo == 'campaign_id') {
                    $linkCampo = 'gestaoUtm_campaign_id';
                    $linkTipo  = 'gestao_campaign_id';
                
                    
                } else if ($tipo == 'adset_id') {
                    $linkCampo = 'gestaoUtm_adset_id';
                    $linkTipo  = 'gestao_adset_id';
                
                    
                } else if ($tipo == 'ad_id') {
                    $linkCampo = 'gestaoUtm_ad_id';
                    $linkTipo  = 'gestao_ad_id';
                    
                }
                
                $arrCodigos = array();
                
                $sql = "SELECT *
                    FROM gestao_utms 
                    WHERE 
                        gestaoUtmSiteEndereco IN ('" . implode("','", $contaSites) . "') AND 
                        DATE(gestaoUtmData)   = '$dataAtual'
                    GROUP BY $linkCampo;";
                
                $lista = mysqli_query($con, $sql); 
                    
                if ($lista) { 
                    $totalAd = mysqli_num_rows($lista);
                    
                    while ($listaValor = mysqli_fetch_array($lista)) {
                        $gestaoUtmValor = $listaValor[$linkCampo];
                        $analyticID    = $listaValor['_analyticID'];
                        
                        $arrCodigos[] = $gestaoUtmValor;
                    }
                    
                    foreach ($arrCodigos as $gestaoUtmValor) {
                        $cadastrado = mysqli_query($con, "SELECT * 
                            FROM gestao_utms_copiados 
                            WHERE 
                                copiadoValor = '$gestaoUtmValor' AND 
                                copiadoTipo  = '$linkTipo' 
                            LIMIT 1"); 
                        
                        if ($cadastrado) {
                            if (mysqli_num_rows($cadastrado) == 0) {
                        
                                if (!empty($network_code)) {
                                    $arquivoNome = rand(1000, 9999) . '.txt';
                                    
                                    $data = array(
                                        'arquivo'         => $arquivoNome ,
                                        'link_copia'      => $linkCopiado,
                                        'network_code'    => $network_code,
                                        'aplication_code' => $aplication_code,
                                        'chave_valor'     => $gestaoUtmValor,
                                        'analyticID'      => $analyticID,
                                        'linkCampo'       => $linkCampo,
                                        'linkTipo'        => $linkTipo,
                                        'tipo'            => $tipo
                                    );
                                    
                                    pre($data);
                                  
                                    file_put_contents($pasta . $arquivoNome, json_encode($data));
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    /*
    $ch = curl_init();
                                        
    curl_setopt($ch, CURLOPT_URL, $linkAtual);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
                                        
    $output = curl_exec($ch);
    curl_close($ch); */
}